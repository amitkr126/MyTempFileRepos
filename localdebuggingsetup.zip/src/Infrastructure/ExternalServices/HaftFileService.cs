using MsgReceiverService.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace MsgReceiverService.Infrastructure.ExternalServices;

public class HaftFileService : IFileService
{
    private readonly HttpClient _client;
    private readonly ILogger<HaftFileService> _logger;

    // We inject HttpClient via IHttpClientFactory
    public HaftFileService(HttpClient client, ILogger<HaftFileService> logger)
    {
        _client = client;
        _logger = logger;
    }

    public async Task<byte[]> DownloadFileAsync(string fileName, CancellationToken ct)
    {
        _logger.LogInformation("Starting download for file {FileName} from HAFT storage", fileName);

        // HttpCompletionOption.ResponseHeadersRead is crucial for performance
        // It returns as soon as the headers are read, ensuring we don't block
        using var response = await _client.GetAsync($"/{fileName}", HttpCompletionOption.ResponseHeadersRead, ct);
        
        response.EnsureSuccessStatusCode();

        var content = await response.Content.ReadAsByteArrayAsync(ct);
        _logger.LogInformation("Successfully downloaded {FileName}. Size: {Size} bytes", fileName, content.Length);
        
        return content;
    }
}