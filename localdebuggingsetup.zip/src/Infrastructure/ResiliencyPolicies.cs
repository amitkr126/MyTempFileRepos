using Polly;
using Polly.Extensions.Http;
using Oracle.ManagedDataAccess.Client;

namespace MsgReceiverService.Infrastructure;

public static class ResiliencyPolicies
{
    // 1. Database Policy (Retry + Circuit Breaker)
    public static IAsyncPolicy GetDbPolicy(ILogger logger)
    {
        var retry = Policy
            .Handle<OracleException>(IsTransientOracleError)
            .Or<TimeoutException>()
            .WaitAndRetryAsync(3, i => TimeSpan.FromSeconds(Math.Pow(2, i)),
                onRetry: (ex, time) => logger.LogWarning(ex, "DB Transient Error. Retrying in {Time}s...", time.TotalSeconds));

        // FIX: Using Positional Arguments to avoid CS1061 errors
        var breaker = Policy
            .Handle<OracleException>()
            .CircuitBreakerAsync(
                5, 
                TimeSpan.FromSeconds(30),
                onBreak: (ex, span) => logger.LogCritical(ex, "DB CIRCUIT OPEN. Duration: {Span}s", span.TotalSeconds),
                onReset: () => logger.LogInformation("DB CIRCUIT CLOSED (Recovered)"));

        return Policy.WrapAsync(breaker, retry);
    }

    // 2. HTTP Retry Policy
    public static IAsyncPolicy<HttpResponseMessage> GetHttpRetryPolicy() =>
        HttpPolicyExtensions.HandleTransientHttpError()
            .WaitAndRetryAsync(3, i => TimeSpan.FromSeconds(Math.Pow(2, i)));

    // 3. HTTP Circuit Breaker
    public static IAsyncPolicy<HttpResponseMessage> GetHttpBreakerPolicy(IServiceProvider sp)
    {
        var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger("HttpResiliency");
        
        return HttpPolicyExtensions.HandleTransientHttpError()
            .CircuitBreakerAsync(
                5, 
                TimeSpan.FromSeconds(30),
                onBreak: (result, span) => logger.LogCritical("HTTP CIRCUIT OPEN. File Server is down."),
                onReset: () => logger.LogInformation("HTTP CIRCUIT CLOSED. File Server recovered."));
    }

    private static bool IsTransientOracleError(OracleException ex) => 
        new[] { 12541, 12170, 12560, 00060, 04031, 03113 }.Contains(ex.Number);
}