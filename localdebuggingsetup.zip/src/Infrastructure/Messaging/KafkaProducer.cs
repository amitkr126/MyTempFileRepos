using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MsgReceiverService.Core.Interfaces;

namespace MsgReceiverService.Infrastructure.Messaging;

public class KafkaProducer : IMessageProducer, IDisposable
{
    private readonly IProducer<string, string> _producer;
    private readonly ILogger<KafkaProducer> _logger;

    public KafkaProducer(IConfiguration config, ILogger<KafkaProducer> logger)
    {
        _logger = logger;
        
        var producerConfig = new ProducerConfig
        {
            BootstrapServers = config["Kafka:BootstrapServers"],
            Acks = Acks.All, 
            MessageSendMaxRetries = 3
        };

        _producer = new ProducerBuilder<string, string>(producerConfig).Build();
    }

    public async Task ProduceAsync(string topic, string key, string value)
    {
        try 
        {
            await _producer.ProduceAsync(topic, new Message<string, string> { Key = key, Value = value });
            _logger.LogInformation("Produced ACK to {Topic} Key: {Key}", topic, key);
        }
        catch (ProduceException<string, string> e)
        {
            _logger.LogError(e, "Failed to produce message to {Topic}", topic);
            throw; 
        }
    }

    public void Dispose()
    {
        _producer?.Flush(TimeSpan.FromSeconds(10));
        _producer?.Dispose();
    }
}