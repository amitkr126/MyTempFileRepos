using Microsoft.EntityFrameworkCore;
using MsgReceiverService.Core.Entities;

namespace MsgReceiverService.Infrastructure.Persistence;

public class MyDbContext : DbContext
{
    public MyDbContext(DbContextOptions<MyDbContext> options) : base(options) { }

    public DbSet<EnvelopeMessage> Envelopes { get; set; }
    public DbSet<EnvelopeMessageText> EnvelopeTexts { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // =========================================================
        // 1. Map EnvelopeMessage -> ENVELOPE_MESSAGE
        // =========================================================
        modelBuilder.Entity<EnvelopeMessage>(entity =>
        {
            entity.ToTable("ENVELOPE_MESSAGE");
            entity.HasKey(e => e.EnvelopeId);

            // Identity Column
            entity.Property(e => e.EnvelopeId)
                  .HasColumnName("ENVELOPE_ID")
                  .ValueGeneratedOnAdd(); 

            // Column Mappings
            entity.Property(e => e.OicId).HasColumnName("OICID");
            entity.Property(e => e.SoNumber).HasColumnName("SONUMBER");
            entity.Property(e => e.MsgType).HasColumnName("MSG_TYPE");
            entity.Property(e => e.Direction).HasColumnName("DIRECTION");
            entity.Property(e => e.Channel).HasColumnName("CHANNEL");
            entity.Property(e => e.Status).HasColumnName("STATUS");
            entity.Property(e => e.TraceId).HasColumnName("TRACE_ID");
            entity.Property(e => e.Region).HasColumnName("REGION");
            entity.Property(e => e.IsPreGso).HasColumnName("ISPREGSO");
            entity.Property(e => e.TryCount).HasColumnName("TRYCOUNT");
            entity.Property(e => e.ErrorCode).HasColumnName("ERROR_CODE");
            entity.Property(e => e.ErrorDescription).HasColumnName("ERROR_DESCRIPTION");
            entity.Property(e => e.ProcessingBy).HasColumnName("PROCESSING_BY");

            // Timestamps
            entity.Property(e => e.CreateDate).HasColumnName("CREATE_DATE");
            entity.Property(e => e.ModifyDate).HasColumnName("MODIFY_DATE");
            entity.Property(e => e.CreateBy).HasColumnName("CREATE_BY");
            entity.Property(e => e.ModifyBy).HasColumnName("MODIFY_BY");
            entity.Property(e => e.PartitionDate).HasColumnName("PARTITION_DATE");
            entity.Property(e => e.StartProcTime).HasColumnName("STARTPROCTIME");

            // Foreign Key
            entity.Property(e => e.EnvMsgTextId).HasColumnName("ENV_MSG_TEXT_ID");

            entity.HasOne(e => e.MessageText)
                  .WithMany()
                  .HasForeignKey(e => e.EnvMsgTextId);
        });

        // =========================================================
        // 2. Map EnvelopeMessageText -> ENVELOPE_MESSAGE_TEXT
        // =========================================================
        modelBuilder.Entity<EnvelopeMessageText>(entity =>
        {
            entity.ToTable("ENVELOPE_MESSAGE_TEXT");
            entity.HasKey(e => e.EnvMsgTextId);

            // Identity Column
            entity.Property(e => e.EnvMsgTextId)
                  .HasColumnName("ENV_MSG_TEXT_ID")
                  .ValueGeneratedOnAdd();

            // [FIX] Fixes ORA-01460 by forcing BLOB binding
            entity.Property(e => e.MsgBlob)
                  .HasColumnName("MSG_BLOB")
                  .HasColumnType("BLOB");

            entity.Property(e => e.FilePath).HasColumnName("FILE_PATH");
            entity.Property(e => e.Region).HasColumnName("REGION");

            // Timestamps
            entity.Property(e => e.CreateDate).HasColumnName("CREATE_DATE");
            entity.Property(e => e.ModifyDate).HasColumnName("MODIFY_DATE");
            entity.Property(e => e.CreateBy).HasColumnName("CREATE_BY");
            entity.Property(e => e.ModifyBy).HasColumnName("MODIFY_BY");
            entity.Property(e => e.PartitionDate).HasColumnName("PARTITION_DATE");
        });

        base.OnModelCreating(modelBuilder);
    }
}