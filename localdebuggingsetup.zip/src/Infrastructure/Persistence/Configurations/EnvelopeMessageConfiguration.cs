using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MsgReceiverService.Core.Entities;

namespace MsgReceiverService.Infrastructure.Persistence.Configurations;

public class EnvelopeMessageConfiguration : IEntityTypeConfiguration<EnvelopeMessage>
{
    public void Configure(EntityTypeBuilder<EnvelopeMessage> builder)
    {
        builder.ToTable("ENVELOPE_MESSAGE", "OOE_BASE");
        
        // Primary Key
        builder.HasKey(e => e.EnvelopeId);
        builder.Property(e => e.EnvelopeId)
            .HasColumnName("ENVELOPE_ID")
            .HasColumnType("NUMBER(30,0)")
            .ValueGeneratedOnAdd(); // GENERATED ALWAYS AS IDENTITY

        // Required Columns (NOT NULL in DDL)
        builder.Property(e => e.OicId).HasColumnName("OICID").HasMaxLength(50).IsRequired();
        builder.Property(e => e.SoNumber).HasColumnName("SONUMBER").HasMaxLength(50).IsRequired();
        builder.Property(e => e.MsgType).HasColumnName("MSG_TYPE").HasMaxLength(50).IsRequired();
        builder.Property(e => e.Channel).HasColumnName("CHANNEL").HasMaxLength(30).IsRequired();
        builder.Property(e => e.TraceId).HasColumnName("TRACE_ID").HasMaxLength(150).IsRequired();
        builder.Property(e => e.Region).HasColumnName("REGION").HasMaxLength(6).IsRequired();
        builder.Property(e => e.CreateBy).HasColumnName("CREATE_BY").HasMaxLength(100).IsRequired();
        builder.Property(e => e.ModifyBy).HasColumnName("MODIFY_BY").HasMaxLength(100).IsRequired();

        // Nullable Columns
        builder.Property(e => e.Direction).HasColumnName("DIRECTION").HasMaxLength(6);
        builder.Property(e => e.Status).HasColumnName("STATUS").HasMaxLength(30);
        builder.Property(e => e.IsPreGso).HasColumnName("ISPREGSO").HasMaxLength(10);
        builder.Property(e => e.TryCount).HasColumnName("TRYCOUNT");
        builder.Property(e => e.ErrorCode).HasColumnName("ERROR_CODE").HasMaxLength(50);
        builder.Property(e => e.ErrorDescription).HasColumnName("ERROR_DESCRIPTION").HasMaxLength(1000);
        builder.Property(e => e.ProcessingBy).HasColumnName("PROCESSING_BY").HasMaxLength(200);

        // Timestamps
        builder.Property(e => e.CreateDate).HasColumnName("CREATE_DATE");
        builder.Property(e => e.ModifyDate).HasColumnName("MODIFY_DATE");
        builder.Property(e => e.PartitionDate).HasColumnName("PARTITION_DATE");
        builder.Property(e => e.StartProcTime).HasColumnName("STARTPROCTIME");

        // Foreign Key
        builder.Property(e => e.EnvMsgTextId).HasColumnName("ENV_MSG_TEXT_ID").HasColumnType("NUMBER(30,0)");

        // Relationship
        builder.HasOne(e => e.MessageText)
               .WithOne()
               .HasForeignKey<EnvelopeMessage>(e => e.EnvMsgTextId)
               .HasConstraintName("FK_ENVELOPE_MSG_ID");
    }
}