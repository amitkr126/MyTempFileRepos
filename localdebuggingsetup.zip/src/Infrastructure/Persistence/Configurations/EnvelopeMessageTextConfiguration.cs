using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MsgReceiverService.Core.Entities;

namespace MsgReceiverService.Infrastructure.Persistence.Configurations;

public class EnvelopeMessageTextConfiguration : IEntityTypeConfiguration<EnvelopeMessageText>
{
    public void Configure(EntityTypeBuilder<EnvelopeMessageText> builder)
    {
        builder.ToTable("ENVELOPE_MESSAGE_TEXT", "OOE_BASE");
        
        // Primary Key
        builder.HasKey(e => e.EnvMsgTextId);
        builder.Property(e => e.EnvMsgTextId)
            .HasColumnName("ENV_MSG_TEXT_ID")
            .HasColumnType("NUMBER(30,0)")
            .ValueGeneratedOnAdd(); // GENERATED ALWAYS AS IDENTITY

        // BLOB
        builder.Property(e => e.MsgBlob)
            .HasColumnName("MSG_BLOB")
            .HasColumnType("BLOB");

        // Required Columns
        builder.Property(e => e.Region).HasColumnName("REGION").HasMaxLength(6).IsRequired();

        // Nullable Columns
        builder.Property(e => e.FilePath).HasColumnName("FILE_PATH").HasMaxLength(200);
        builder.Property(e => e.CreateBy).HasColumnName("CREATE_BY").HasMaxLength(100);
        builder.Property(e => e.ModifyBy).HasColumnName("MODIFY_BY").HasMaxLength(100);
        
        // Timestamps
        builder.Property(e => e.CreateDate).HasColumnName("CREATE_DATE");
        builder.Property(e => e.ModifyDate).HasColumnName("MODIFY_DATE");
        builder.Property(e => e.PartitionDate).HasColumnName("PARTITION_DATE");
    }
}