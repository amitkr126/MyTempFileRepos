using Confluent.Kafka;
using MsgReceiverService.Core.Interfaces;
using Polly;

namespace MsgReceiverService;

public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly IServiceProvider _serviceProvider;
    private readonly IConfiguration _config;

    public Worker(ILogger<Worker> logger, IServiceProvider serviceProvider, IConfiguration config)
    {
        _logger = logger;
        _serviceProvider = serviceProvider;
        _config = config;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var consumerConfig = new ConsumerConfig
        {
            BootstrapServers = _config["Kafka:BootstrapServers"],
            GroupId = "oic-receiver-group-v2",
            AutoOffsetReset = AutoOffsetReset.Earliest,
            EnableAutoCommit = false, // We commit manually after processing
            // Production Tuning
            SessionTimeoutMs = 6000, 
            StatisticsIntervalMs = 5000 
        };

        // OUTER LOOP: Reconnects to Kafka if the broker connection is lost permanently
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var consumer = new ConsumerBuilder<string, string>(consumerConfig)
                    .SetErrorHandler((_, e) => _logger.LogError($"Kafka Error: {e.Reason}"))
                    .Build();

                consumer.Subscribe("OIC.Notifications.Inbound");
                _logger.LogInformation("Kafka Consumer Started & Subscribed.");

                // INNER LOOP: Consumes messages
                while (!stoppingToken.IsCancellationRequested)
                {
                    try
                    {
                        var result = consumer.Consume(stoppingToken);
                        if (result == null) continue;

                        using (var scope = _serviceProvider.CreateScope())
                        {
                            var processor = scope.ServiceProvider.GetRequiredService<IMessageProcessor>();
                            
                            // Process Message (Business Logic)
                            // We do NOT catch exceptions here because OicMessageProcessor handles its own logic.
                            // If it throws here, it's a critical infrastructure failure.
                            await processor.ProcessOicMessageAsync(
                                result.Message.Key ?? "UNKNOWN", 
                                result.Message.Value, 
                                stoppingToken);
                                
                            consumer.Commit(result); // Commit Offset
                        }
                    }
                    catch (ConsumeException cx)
                    {
                        // Protocol errors (e.g., deserialization issues). Log and continue.
                        _logger.LogError(cx, "Kafka Consume Error. Continuing loop.");
                    }
                    catch (Exception ex)
                    {
                        // Catch-all for unexpected crashes to prevent container death
                        _logger.LogError(ex, "CRITICAL: Unhandled exception in processing loop. Pausing briefly.");
                        await Task.Delay(1000, stoppingToken); // Backoff to prevent CPU spin
                    }
                }
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Worker stopping gracefully.");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "FATAL: Kafka Connection Failed. Retrying in 5 seconds...");
                await Task.Delay(5000, stoppingToken); // Wait before reconnecting
            }
        }
    }
}