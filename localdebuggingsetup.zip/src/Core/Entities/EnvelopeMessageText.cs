namespace MsgReceiverService.Core.Entities;

public class EnvelopeMessageText
{
    // [FIX] Change double to long
    public long EnvMsgTextId { get; set; }

    // ... Keep all other properties exactly as they are ...
    public byte[]? MsgBlob { get; set; }
    public string? FilePath { get; set; }
    public string Region { get; set; } = string.Empty;

    public DateTimeOffset CreateDate { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset ModifyDate { get; set; } = DateTimeOffset.UtcNow;
    public string? CreateBy { get; set; } = "SYSTEM";
    public string? ModifyBy { get; set; } = "SYSTEM";
    public DateTimeOffset? PartitionDate { get; set; }
}