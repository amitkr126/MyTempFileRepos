namespace MsgReceiverService.Core.Entities;

public class EnvelopeMessage
{
    // [FIX] Change double to long
    public long EnvelopeId { get; set; } 

    // [FIX] Change double? to long? (Foreign Key)
    public long? EnvMsgTextId { get; set; }

    // ... Keep all other properties exactly as they are ...
    public string OicId { get; set; } = string.Empty;
    public string SoNumber { get; set; } = string.Empty;
    public string MsgType { get; set; } = string.Empty;
    public string TraceId { get; set; } = string.Empty;
    public string Channel { get; set; } = "KAFKA"; 
    public string Region { get; set; } = string.Empty;
    public string? Status { get; set; }
    public string? Direction { get; set; }
    public string? IsPreGso { get; set; }
    public double? TryCount { get; set; } // This is fine as double or int
    public string? ErrorCode { get; set; }
    public string? ErrorDescription { get; set; }
    public string? ProcessingBy { get; set; }

    public virtual EnvelopeMessageText? MessageText { get; set; }

    public DateTimeOffset CreateDate { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset ModifyDate { get; set; } = DateTimeOffset.UtcNow;
    public string CreateBy { get; set; } = "SYSTEM";
    public string ModifyBy { get; set; } = "SYSTEM";
    public DateTimeOffset? PartitionDate { get; set; }
    public DateTimeOffset? StartProcTime { get; set; }
}