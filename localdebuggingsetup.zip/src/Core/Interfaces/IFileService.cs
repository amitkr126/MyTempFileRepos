namespace MsgReceiverService.Core.Interfaces;

public interface IFileService
{
    Task<byte[]> DownloadFileAsync(string fileName, CancellationToken ct);
}