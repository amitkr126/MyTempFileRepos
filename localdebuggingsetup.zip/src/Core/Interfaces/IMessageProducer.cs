namespace MsgReceiverService.Core.Interfaces;

public interface IMessageProducer
{
    Task ProduceAsync(string topic, string key, string value);
}