namespace MsgReceiverService.Core.Interfaces;

public interface IMessageProcessor
{
    Task ProcessOicMessageAsync(string messageKey, string jsonPayload, CancellationToken ct);
}