using Microsoft.EntityFrameworkCore;
using Polly;
using Serilog;
using Confluent.Kafka;
using OpenTelemetry.Resources;
using OpenTelemetry.Metrics; // Required for Grafana WithMetrics
using OpenTelemetry.Trace;   // Required for Grafana WithTracing
using MsgReceiverService;
using MsgReceiverService.Core.Interfaces;
using MsgReceiverService.Core.Services;
using MsgReceiverService.Infrastructure; 
using MsgReceiverService.Infrastructure.Persistence;
using MsgReceiverService.Infrastructure.ExternalServices;
using MsgReceiverService.Infrastructure.Messaging;

var builder = WebApplication.CreateBuilder(args);

// 1. OBSERVABILITY (Logs)
Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .CreateLogger();

builder.Logging.ClearProviders();
builder.Logging.AddSerilog();

// 2. OPEN TELEMETRY (Tracing & Metrics)
builder.Services.AddOpenTelemetry()
    .WithTracing(t =>
    {
        t.SetResourceBuilder(ResourceBuilder.CreateDefault().AddService("MsgReceiverService"))
         .AddAspNetCoreInstrumentation()
         .AddHttpClientInstrumentation()
         .AddEntityFrameworkCoreInstrumentation(o => o.SetDbStatementForText = true)
         .AddOtlpExporter(); 
    })
    // 👇 THIS BLOCK WAS MISSING. IT IS REQUIRED FOR PROMETHEUS. 👇
    .WithMetrics(metrics => 
    {
        metrics
            .AddAspNetCoreInstrumentation()
            .AddHttpClientInstrumentation()
            .AddRuntimeInstrumentation() // CPU, Memory, etc.
            .AddPrometheusExporter();    // Registers the MeterProvider
    });

// 3. DATABASE
var connectionString = builder.Configuration.GetConnectionString("OracleDb");
builder.Services.AddDbContextPool<MyDbContext>(options =>
{
    options.UseOracle(connectionString, o => o.CommandTimeout(30));
});

// Register Policy as Singleton
builder.Services.AddSingleton<IAsyncPolicy>(sp => 
{
    var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger("DatabaseResiliency");
    return ResiliencyPolicies.GetDbPolicy(logger);
});

// 4. INFRASTRUCTURE
builder.Services.AddSingleton<IMessageProducer, KafkaProducer>();

builder.Services.AddHttpClient<IFileService, HaftFileService>(client =>
{
    var url = builder.Configuration["Apis:FileServerUrl"] ?? "http://localhost:8080";
    client.BaseAddress = new Uri(url);
})
.AddPolicyHandler(ResiliencyPolicies.GetHttpRetryPolicy())
.AddPolicyHandler((sp, msg) => ResiliencyPolicies.GetHttpBreakerPolicy(sp));

// 5. DOMAIN
builder.Services.AddScoped<IMessageProcessor, OicMessageProcessor>();
builder.Services.AddHostedService<Worker>();

// 6. HEALTH CHECKS
builder.Services.AddHealthChecks()
    .AddDbContextCheck<MyDbContext>("OracleDB") 
    .AddKafka(new ProducerConfig 
    { 
        BootstrapServers = builder.Configuration["Kafka:BootstrapServers"] ?? "localhost:9092" 
    }, name: "Kafka");

var app = builder.Build();

app.UseRouting();
app.MapHealthChecks("/health");

// This will now work because .WithMetrics() is configured above
app.MapPrometheusScrapingEndpoint(); 

app.Run();