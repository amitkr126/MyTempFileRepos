# MsgReceiverService
    Basically The core Design is like we have 3 microservices, And The 1st is Receiver service, Kafka consumer based service, It is the Entry Point for the Fulfilment system, We have to consume the notification message(Lightweight Json) from external Kafka Topic, The pick the actual file (File name found in this Notification Message), persist the file in blob in Oracle DB, and file persistedthen Acknowledge the sender of message as ACK message in response via my Kafka Producr to Kafka Producer Topic.

### The message receiving from Kafka, its a json lightweight message(Attached Below in this readme), 
    {
        "messageType": "PreGSONotification",
        "messageCreateBy": "OIC",
        "messageId": "777786cf-cd59-4c09-91c6-4f39fa0480a5",
        "messageCreateDate": "2025-10-27T09:29:11.1515732+00:00",
        "version": "2.0",
        "messageDetail": {
            "OICId": "aa94a9ba-6057-4643-b82d-a7a787a0d883",
            "SONumber": "4860151392",
            "region": "AMER",
            "fulfillments": [
                {
                        "fulfillmentId": "5326167358"
                }
            ],
        "fileName": "TGSO_V21_4860151392_aa94a9ba-6057-4643-b82d-a7a787a0d883_5326167358.json"
        }
    }
    
This Notification message will be stored in my Oracle DB and table name is  ENVELOPE_MESSAGE table,
then our program will read a file (example : TGSO_V21_4860151392_aa94a9ba-6057-4643-b82d-a7a787a0d883_5326167358.json) came in light weight message from dropbox kind of storage,  once Program download the file provided as fileName in notification message, it will be stored in DB Blob in another table ENVELOPE_MESSAGE_TEXT.

We also Need to deploy it to KOB(Kubernetes), We need to enable Monitoring with Grafana and Dynatrace, We also need to enble splunk logging using Serilog as it is best structured way to log the allication logs.

## Plan Layout for this First service

### Prerequisite
    Install the Visual Studio Code Latest 
    Install .Net 10 SDK if possible, or .Net 8 SDK, but it will really give the issue
    Install WSL 2.0 and run ubuntu in your WSL after installing ubuntu Welcome to Ubuntu 24.04.3 LTS
    Install podman and podman desktop
    
<sub>  **podman machine init**
**podman machine start**
**podman system connection list** </sub>

Very Critical: Open Podman Desktop and enable the Podman COmpose, so that it will work like docket compose, we can also enable docker compatibility then run below command
  podman compose up -d

# MsgReceiverService (.NET 10)

## Overview
MsgReceiverService is a high-performance, resilient microservice designed as the entry point for the Order Integration Cloud (OIC) pipeline. 
It handles asynchronous event consumption from Kafka, performs data enrichment via external storage (Dropbox-style API), 
and ensures data persistence in Oracle DB with a transactional ACK/NACK feedback loop.

## Architecture & Design Patterns
* **Clean Architecture:** Separation of concerns between Domain, Application, and Infrastructure layers.
* **Idempotent Consumer:** Ensures that duplicate Kafka messages are handled without corrupting DB state.
* **Transactional Messaging:** Only issues a Kafka ACK to the outbound topic after successful DB persistence and file enrichment.
* **Streaming BLOB Injection:** Optimized memory management by streaming files from storage directly to Oracle BLOBs, avoiding OOM (Out of Memory) issues in Kubernetes.

---

## Technical Stack
* **Runtime:** .NET 10 (Worker Service)
* **Messaging:** Confluent Kafka (Consumer & Producer)
* **Database:** Oracle Database (EF Core 10 Managed Provider)
* **Resilience:** Polly v8 (Hedging, Circuit Breaker, and Retries)
* **Observability:** * **Logging:** Serilog with Splunk HEC (HTTP Event Collector) Sink.
    * **Tracing:** OpenTelemetry (OTLP) integrated with Dynatrace.
    * **Metrics:** Prometheus/Grafana for throughput and error rate tracking.
* **Deployment:** Kubernetes (K8s) with Helm 3.

---

## Data Structures

### Incoming Kafka JSON (PreGSONotification)
        ```json
        {
          "messageType": "PreGSONotification",
          "messageId": "777786cf-cd59-4c09-91c6-4f39fa0480a5",
          "messageCreateDate": "2025-10-27T09:29:11.1515732+00:00",
          "messageDetail": {
            "OICId": "aa94a9ba-6057-4643-b82d-a7a787a0d883",
            "SONumber": "4860151392",
            "region": "AMER",
            "fileName": "TGSO_V21_..._5326167358.json"
          }
        }
        ```

## Database Schema
   #  ENVELOPE_MESSAGE: Primary tracking table for lightweight metadata and lifecycle status.
   #  ENVELOPE_MESSAGE_TEXT: Dedicated table for BLOB storage to optimize table scans on the base table.

## Processing Workflow
  #  Consume: Polls OIC.Notifications.Inbound topic.
  #  Validate: Schema validation and TraceID extraction.
  #  Persist Metadata: Create record in ENVELOPE_MESSAGE with status RECEIVED.
  #  Enrich: Fetch file from Dropbox-like storage using the fileName provided in the payload.
  #  Persist BLOB: Stream file content into ENVELOPE_MESSAGE_TEXT.
  #  Acknowledge: Produce an ACK message to OIC.Notifications.ACK topic.
  #  Commit: Manually commit Kafka offset to ensure "At-Least-Once" delivery.

## Observability & Monitoring
  #  Splunk: All structured logs are sent to Splunk via Serilog. Filter by TraceId for end-to-end request visibility.
  #  Dynatrace: Distributed tracing enabled via OpenTelemetry. Automatically captures Oracle DB latency and Kafka consumer lag.
  #  Grafana: Dashboard monitors Pod health (CPU/Memory), Kafka Consumer Group lag, and DB Connection Pool utilization.


## Process like greenfield implementation
------------------------------------------------
# 1. Create the Solution
  dotnet new sln -n MsgReceiverService

# 2. Create the Worker Service Project
  dotnet new worker -n MsgReceiverService -o src

# 3. Add the project to the solution
  dotnet sln add src/MsgReceiverService.csproj 

# Move into the project folder
  cd src

          dotnet add package Microsoft.EntityFrameworkCore
          dotnet add package Microsoft.EntityFrameworkCore.Relational
          dotnet add package Oracle.EntityFrameworkCore
          dotnet add package Confluent.Kafka
          dotnet add package Microsoft.Extensions.Hosting
          dotnet add package Microsoft.Extensions.Http.Polly
          dotnet add package Polly
          dotnet add package Serilog.AspNetCore
          dotnet add package Serilog.Sinks.Splunk
          dotnet add package OpenTelemetry.Extensions.Hosting
          dotnet add package OpenTelemetry.Instrumentation.Http
          dotnet add package OpenTelemetry.Instrumentation.EntityFrameworkCore
          dotnet add package OpenTelemetry.Exporter.OpenTelemetryProtocol
          dotnet add package Microsoft.Extensions.Diagnostics.HealthChecks.EntityFrameworkCore
          dotnet add package Serilog.Formatting.Compact
          dotnet add package OpenTelemetry.Exporter.Prometheus.AspNetCore
          dotnet add package OpenTelemetry.Instrumentation.Runtime

## Make Folders
    mkdir Core
    mkdir Core\Entities
    mkdir Core\Interfaces
    mkdir Infrastructure
    mkdir Infrastructure\Persistence
    mkdir Infrastructure\Persistence\Configurations
    mkdir Infrastructure\ExternalServices
    mkdir Infrastructure\Messaging

## Building & Running this Project

### Step 1. Open PowerShell and navigate to the setup folder:
    cd C:\Coding\OOE\msgreceiverservice\localdebuggingsetup

### Step 2. Start the containers:
    podman compose -f compose.yaml up -d
    podman compose -f observability.yaml up -d

### Step 3. WAIT for Oracle (Crucial): Oracle 19c takes 3 to 5 minutes to initialize and create the user/tables on the first run. Monitor the progress:
    podman logs -f ooe-oracle-19c

### Step 4. Prepare Mock Data as Create the folder (if missing) in the project root:
    mkdir ..\MockData

### Step 5. Copy your test file (TGSO_V21_....json) into this folder.

### Step 6. Verify Access: Open your browser to:
    http://localhost:8080/TGSO_V21_4860151392_aa94a9ba-6057-4643-b82d-a7a787a0d883_5326167358.json (If the file downloads, the Mock File Server is working).

### Step 7. Run the Service
    I used Visual Studio COde so as per my setup Open a NEW Terminal in the source folder:
      cd src
      dotnet run
    You should see logs indicating the service has connected to Kafka:
    info: MsgReceiverService.Worker[0] Kafka Consumer Started...

### Step 8. Trigger an End-to-End Test by Opening a THIRD Terminal.
    Start the Kafka Console Producer:
      podman exec -it ooe-kafka kafka-console-producer --broker-list localhost:9092 --topic OIC.Notifications.Inbound

### Step 9.  Let us Paste the Trigger JSON: (Copy this whole block and paste it into the terminal, then hit Enter), we can change the contents of this message based on filename and test scanario in local
{"messageType":"PreGSONotification","messageCreateBy":"OIC","messageId":"TRACE-TEST-001","messageCreateDate":"2025-10-27T09:29:11.1515732+00:00","version":"2.0","messageDetail":{"OICId":"aa94a9ba-6057-4643-b82d-a7a787a0d883","SONumber":"4860151392","region":"AMER","fulfillments":[{"fulfillmentId":"5326167358"}],"fileName":"TGSO_V21_4860151392_aa94a9ba-6057-4643-b82d-a7a787a0d883_5326167358.json"}}

### Step 10. Now Let Us Verify Success
  1. Check Application Logs
  Go back to your .NET Run terminal. You should see:

      Metadata saved for TRACE-TEST-001...

      Downloading file: TGSO_V21...

      Processing Complete for TRACE-TEST-001

  2. Verify Database (Oracle)
    Connect via SQL Developer:
      Host: localhost
      Port: 1521
      Service Name: ORCLPDB1 (⚠️ Do NOT use SID)
      User: OOE_BASE
      Pass: Password123
      Run this query  :

      SQL
      SELECT * FROM ENVELOPE_MESSAGE WHERE TRACE_ID = 'TRACE-TEST-001';
      -- Status should be 'COMPLETED'

  3. Verify Kafka ACK
  Check if the service sent the acknowledgement back:

  PowerShell
  podman exec -it ooe-kafka kafka-console-consumer --bootstrap-server localhost:9092 --topic OIC.Notifications.ACK --from-beginning
  Expected: {"Status":"Success","RefId":1...}

  ### Step 11. Now Let Us Verify SuccessCleanUp TIme, We had lots of fund --  To stop everything and free up resources:
      cd localdebuggingsetup
      podman-compose down


Testing
----------------------------------------------------------
podman exec -it ooe-kafka kafka-console-producer --broker-list localhost:9092 --topic OIC.Notifications.Inbound

{"messageType":"PreGSONotification","messageCreateBy":"OIC","messageId":"777786cf-cd59-4c09-91c6-4f39fa0480a5","messageCreateDate":"2025-10-27T09:29:11.1515732+00:00","version":"2.0","messageDetail":{"OICId":"aa94a9ba-6057-4643-b82d-a7a787a0d883","SONumber":"4860151392","region":"AMER","fulfillments":[{"fulfillmentId":"5326167358"}],"fileName":"TGSO_V21_4860151392_aa94a9ba-6057-4643-b82d-a7a787a0d883_5326167358.json"}}

Nack Check  - Outbound Kafka
podman exec -it ooe-kafka kafka-console-consumer --bootstrap-server localhost:9092 --topic OIC.Notifications.ACK --from-beginning


## Running my Splunk Locally on port http://localhost:8000/

http://localhost:8000/en-US/app/search/search?q=search%20index%3D%22main%22&sid=1770673662.38&display.page.search.mode=smart&dispatch.sample_ratio=1&workload_pool=&earliest=-24h%40h&latest=now

Step 1: Enable HEC in Splunk (One-Time Setup)
Log in to Splunk: http://localhost:8000

User: admin

Pass: Password123

Go to Settings (top right) ➡️ Data Inputs.

Click on HTTP Event Collector.

Click the Global Settings button (top right of the list).

All Tokens: Click Enabled.

Enable SSL: Uncheck this (since we are using http locally).

HTTP Port Number: Leave as 8088.

Click Save.

Step 2: Create the Token
still in HTTP Event Collector, click the green New Token button (top right).

Name: Enter MsgReceiver.

Click Next.

Index: Click on main in the "Available item(s)" list to move it to "Selected item(s)".

Click Review ➡️ Submit.

COPY THE TOKEN VALUE (It looks like a GUID, e.g., 11111111-2222-3333-4444-555555555555).

Step 3: Update C# appsettings.json
Open your src/appsettings.json and update the Serilog section. Paste your token inside the Args.

JSON
{
  "Serilog": {
    "Using": [ "Serilog.Sinks.Console", "Serilog.Sinks.Splunk" ],
    "MinimumLevel": {
      "Default": "Information",
      "Override": {
        "Microsoft": "Warning",
        "System": "Warning"
      }
    },
    "WriteTo": [
      { "Name": "Console" },
      {
        "Name": "EventCollector",
        "Args": {
          "splunkHost": "http://localhost:8088",
          "eventCollectorToken": "PASTE-YOUR-TOKEN-HERE", 
          "source": "MsgReceiverService",
          "index": "main"
        }
      }
    ]
  }
}
Step 4: Run & Search
Restart your App:

PowerShell
dotnet run
Go back to Splunk UI.

Click on Search & Reporting (left sidebar).

Type this query in the search bar and hit Enter:

Code snippet
index="main"


# Few Troubleshooting steps inside podman container

podman images 

podman compose -f compose.yaml up -d  
podman compose -f observability.yaml up -d  

or  podman compose down   - One shot

## Bring Down
----------------
podman compose -f observability.yaml down   
podman compose -f compose.yaml down  

podman volume prune -f    

See container logs with container name from your yaml
-------------------------------------
podman logs -f ooe-kafka     


To run only one service from compose file
-------------------------------------------------------
podman compose up -d zookeeper     
podman compose up -d ooe-kafka  
podman rm -f ooe-zookeeper  
podman rm -f ooe-kafka  


podman compose -f observability.yaml down
podman compose -f compose.yaml down


Splunk : http://localhost:8000
Grafana : http://localhost:3000
Prometheous: http://localhost:9090



# For Inbound Kafka Messaging view

 podman exec -it ooe-kafka kafka-console-producer --broker-list localhost:9092 --topic OIC.Notifications.Inbound

{"messageType":"PreGSONotification","messageCreateBy":"OIC","messageId":"777786cf-cd59-4c09-91c6-4f39fa0480a5","messageCreateDate":"2025-10-27T09:29:11.1515732+00:00","version":"2.0","messageDetail":{"OICId":"aa94a9ba-6057-4643-b82d-a7a787a0d883","SONumber":"4860151392","region":"AMER","fulfillments":[{"fulfillmentId":"5326167358"}],"fileName":"TGSO_V21_4860151392_aa94a9ba-6057-4643-b82d-a7a787a0d883_5326167358.json"}}

# for outbound Kafka Messaging view

podman exec -it ooe-kafka kafka-console-consumer --bootstrap-server localhost:9092 --topic OIC.Notifications.ACK --from-beginning


